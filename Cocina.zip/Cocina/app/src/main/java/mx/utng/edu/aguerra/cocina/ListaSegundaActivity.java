package mx.utng.edu.aguerra.cocina;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaSegundaActivity extends AppCompatActivity {

    private ListView listSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_secundario);
        //Relacionar xml con clase JAVA
        listSelected = (ListView) findViewById(R.id.lsv_menu2);

        //Array para cargar ListView
        ArrayList<String> platilloSeleccionado = new ArrayList<>();
        platilloSeleccionado.add("Pozole");
        platilloSeleccionado.add("Tacos");
        platilloSeleccionado.add("Mole Amarillo");
        platilloSeleccionado.add("Tamales");
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,platilloSeleccionado);
        listSelected.setAdapter(adapter);

        //Evento OnClick
        listSelected.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListaSegundaActivity.this, VistaDetalleActivity.class);
                startActivity(intent);
            }
        });
    }
}/*End*/

